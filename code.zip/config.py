"""
config.py — Central configuration for the Buy or Wait financial agent.
"""
import os
from pathlib import Path

# ── Repo root (the directory containing this code/ folder) ──────────────────
REPO_ROOT = Path(__file__).parent.parent
DATASET_DIR = REPO_ROOT / "dataset"
MEDIA_DIR = DATASET_DIR / "media" / "images"
CODE_DIR = REPO_ROOT / "code"

# ── Output ───────────────────────────────────────────────────────────────────
OUTPUT_CSV = REPO_ROOT / "output.csv"
USAGE_REPORT = REPO_ROOT / "evaluation" / "usage_report.md"
IMAGE_CACHE_FILE = CODE_DIR / ".image_cache.json"

# ── Dataset file paths ───────────────────────────────────────────────────────
REQUESTS_CSV = DATASET_DIR / "requests.csv"
SAMPLE_REQUESTS_CSV = DATASET_DIR / "sample_requests.csv"
FINANCIAL_PROFILES_CSV = DATASET_DIR / "financial_profiles.csv"
FINANCIAL_EVENTS_CSV = DATASET_DIR / "financial_events.csv"
EXCHANGE_RATES_CSV = DATASET_DIR / "exchange_rates.csv"
PAYMENT_OPTIONS_CSV = DATASET_DIR / "request_payment_options.csv"
MESSAGES_CSV = DATASET_DIR / "messages.csv"
IMAGES_CSV = DATASET_DIR / "images.csv"

# ── Simulation parameters ─────────────────────────────────────────────────────
FORECAST_DAYS = 90

# ── LLM / VLM ────────────────────────────────────────────────────────────────
# Set GOOGLE_API_KEY in your environment
GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY", "")

# Model for text (message parsing + explanation generation)
LLM_MODEL = "gemini-2.0-flash"

# Model for vision (image amount extraction)
VLM_MODEL = "gemini-2.0-flash"

# ── Recurrence inference ──────────────────────────────────────────────────────
# Minimum occurrences in history to consider an expense recurring
MIN_RECURRENCE_COUNT = 2

# Max variance in day-of-month (±days) to consider salary "monthly on same day"
SALARY_DAY_VARIANCE = 3

# Max coefficient of variation to treat an amount as "stable"
AMOUNT_CV_THRESHOLD = 0.15

# ── Binary search precision ───────────────────────────────────────────────────
BINARY_SEARCH_ITERATIONS = 50

# ── Output formatting ─────────────────────────────────────────────────────────
AMOUNT_DECIMAL_PLACES = 2
